package com.example.immaculee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.immaculee.ui.login.Login;

public class MainActivity extends AppCompatActivity {


    EditText username, password;
    Button login , register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText)findViewById(R.id.user);
        password = (EditText)findViewById(R.id.password);
        login = (Button)findViewById(R.id.button);
        register = (Button)findViewById(R.id.regbtn);



        register.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){

                 Intent intent = new Intent(MainActivity.this, Login.class);
                 startActivity(intent);
                login();

            }
        });

    }
    public void login(){
        initialize();
        if (!validate()){
            Toast.makeText(this,"signup  valid",Toast.LENGTH_LONG).show();
        }else {
            onSignupSuccess();
        }
    }
    public void onSignupSuccess(){

    }
    public boolean validate(){
        boolean valid =true;
        if (username.equals("admin")&& password.equals("1234")){

            valid = false ;

            Intent intent = new Intent(MainActivity.this, Login.class);
            startActivity(intent);
        }

        return valid;
    }

    public void initialize(){
         username.getText().toString().trim();
         password.getText().toString().trim();


    }

}
